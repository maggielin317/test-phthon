import animal

cat = animal.Animal("cat","fish")
cat.eat()