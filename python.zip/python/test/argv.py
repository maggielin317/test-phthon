#sys.argv 是用來取得執行 Python 檔案時命令列參數的方法

import sys

print(sys.argv[0])