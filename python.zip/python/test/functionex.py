# def testPrint():
#     print("test print function")
# testPrint()


# def max(a,b):
#     if a>b :
#         return a
#     else:
#         return b
    
# def max(a, b):
#     return a if a > b else b
# print(str(max(1,2)))


# def myprint():
#     print("hello world")

# return_value = myprint()
# print(return_value)



# def myfunc():
#     return (1,2,3)

# re = myfunc()
# print(re)
# print(type(re))



# def student():
#     return 1,'tom'

# # re = student()
# # print(re)
# # print(type(re))

# id, name = student()
# print(str(id) +" : "+ name)


